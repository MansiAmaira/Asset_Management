import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAssets, createAsset, updateAsset, deleteAsset } from '../store/assetSlice';

export default function AssetList() {
  const dispatch = useDispatch();
  const { list, loading } = useSelector((state) => state.assets);
  const [showModal, setShowModal] = useState(false);
  const [editingAsset, setEditingAsset] = useState(null);
  const [filterStatus, setFilterStatus] = useState('');
  const [filterType, setFilterType] = useState('');
  const [searchSerial, setSearchSerial] = useState('');
  const [formData, setFormData] = useState({
    assetName: '', assetType: '', makeModel: '', serialNumber: '',
    purchaseDate: '', warrantyExpiryDate: '', condition: 'NEW',
    status: 'AVAILABLE', isSpare: false, specifications: ''
  });

  useEffect(() => {
    dispatch(fetchAssets());
  }, [dispatch]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingAsset) {
      await dispatch(updateAsset({ id: editingAsset.id, data: formData }));
    } else {
      await dispatch(createAsset(formData));
    }
    resetForm();
    dispatch(fetchAssets());
  };

  const handleEdit = (asset) => {
    setEditingAsset(asset);
    setFormData(asset);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this asset?')) {
      await dispatch(deleteAsset(id));
    }
  };

  const resetForm = () => {
    setFormData({ assetName: '', assetType: '', makeModel: '', serialNumber: '', purchaseDate: '', warrantyExpiryDate: '', condition: 'NEW', status: 'AVAILABLE', isSpare: false, specifications: '' });
    setEditingAsset(null);
    setShowModal(false);
  };

  const filteredList = list.filter(asset => {
    if (filterStatus && asset.status !== filterStatus) return false;
    if (filterType && asset.assetType !== filterType) return false;
    if (searchSerial && !asset.serialNumber.toLowerCase().includes(searchSerial.toLowerCase())) return false;
    return true;
  });

  const uniqueTypes = [...new Set(list.map(a => a.assetType))];

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h2>Asset Management</h2>
        <button onClick={() => setShowModal(true)} style={{ padding: '0.75rem 1.5rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
          Add Asset
        </button>
      </div>

      <div style={{ backgroundColor: 'white', padding: '1rem', borderRadius: '8px', marginBottom: '1rem', display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
        <div>
          <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem' }}>Filter by Status</label>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} style={{ padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}>
            <option value="">All Statuses</option>
            <option value="AVAILABLE">Available</option>
            <option value="ASSIGNED">Assigned</option>
            <option value="UNDER_REPAIR">Under Repair</option>
            <option value="RETIRED">Retired</option>
          </select>
        </div>
        <div>
          <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem' }}>Filter by Type</label>
          <select value={filterType} onChange={(e) => setFilterType(e.target.value)} style={{ padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}>
            <option value="">All Types</option>
            {uniqueTypes.map(type => <option key={type} value={type}>{type}</option>)}
          </select>
        </div>
        <div>
          <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem' }}>Search Serial Number</label>
          <input type="text" value={searchSerial} onChange={(e) => setSearchSerial(e.target.value)} placeholder="Enter serial number" style={{ padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
        </div>
      </div>

      <div style={{ backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
          <thead style={{ backgroundColor: '#f8f9fa' }}>
            <tr>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>ID</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Name</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Type</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Serial</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Condition</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Status</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Spare</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredList.map((asset) => (
              <tr key={asset.id} style={{ borderBottom: '1px solid #dee2e6' }}>
                <td style={{ padding: '0.75rem' }}>{asset.id}</td>
                <td style={{ padding: '0.75rem' }}>{asset.assetName}</td>
                <td style={{ padding: '0.75rem' }}>{asset.assetType}</td>
                <td style={{ padding: '0.75rem' }}>{asset.serialNumber}</td>
                <td style={{ padding: '0.75rem' }}>{asset.condition}</td>
                <td style={{ padding: '0.75rem' }}>
                  <span style={{ padding: '0.25rem 0.5rem', borderRadius: '12px', fontSize: '0.75rem', backgroundColor: asset.status === 'AVAILABLE' ? '#d4edda' : asset.status === 'ASSIGNED' ? '#fff3cd' : '#f8d7da', color: asset.status === 'AVAILABLE' ? '#155724' : asset.status === 'ASSIGNED' ? '#856404' : '#721c24' }}>
                    {asset.status}
                  </span>
                </td>
                <td style={{ padding: '0.75rem' }}>{asset.isSpare ? 'Yes' : 'No'}</td>
                <td style={{ padding: '0.75rem' }}>
                  <button onClick={() => handleEdit(asset)} style={{ padding: '0.25rem 0.5rem', marginRight: '0.5rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '0.75rem' }}>Edit</button>
                  <button onClick={() => handleDelete(asset.id)} style={{ padding: '0.25rem 0.5rem', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '0.75rem' }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 }}>
          <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '8px', width: '100%', maxWidth: '700px', maxHeight: '90vh', overflow: 'auto' }}>
            <h3 style={{ marginBottom: '1.5rem' }}>{editingAsset ? 'Edit Asset' : 'Add Asset'}</h3>
            <form onSubmit={handleSubmit}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Asset Name</label>
                  <input type="text" value={formData.assetName} onChange={(e) => setFormData({...formData, assetName: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Asset Type</label>
                  <input type="text" value={formData.assetType} onChange={(e) => setFormData({...formData, assetType: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Make/Model</label>
                  <input type="text" value={formData.makeModel} onChange={(e) => setFormData({...formData, makeModel: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Serial Number</label>
                  <input type="text" value={formData.serialNumber} onChange={(e) => setFormData({...formData, serialNumber: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Purchase Date</label>
                  <input type="date" value={formData.purchaseDate} onChange={(e) => setFormData({...formData, purchaseDate: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Warranty Expiry</label>
                  <input type="date" value={formData.warrantyExpiryDate} onChange={(e) => setFormData({...formData, warrantyExpiryDate: e.target.value})} style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Condition</label>
                  <select value={formData.condition} onChange={(e) => setFormData({...formData, condition: e.target.value})} style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}>
                    <option value="NEW">New</option>
                    <option value="GOOD">Good</option>
                    <option value="NEEDS_REPAIR">Needs Repair</option>
                    <option value="DAMAGED">Damaged</option>
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Status</label>
                  <select value={formData.status} onChange={(e) => setFormData({...formData, status: e.target.value})} style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}>
                    <option value="AVAILABLE">Available</option>
                    <option value="ASSIGNED">Assigned</option>
                    <option value="UNDER_REPAIR">Under Repair</option>
                    <option value="RETIRED">Retired</option>
                  </select>
                </div>
              </div>
              <div style={{ marginTop: '1rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <input type="checkbox" checked={formData.isSpare} onChange={(e) => setFormData({...formData, isSpare: e.target.checked})} />
                  <span>Is Spare Asset</span>
                </label>
              </div>
              <div style={{ marginTop: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Specifications</label>
                <textarea value={formData.specifications} onChange={(e) => setFormData({...formData, specifications: e.target.value})} rows="3" style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
              </div>
              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
                <button type="button" onClick={resetForm} style={{ padding: '0.5rem 1rem', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" style={{ padding: '0.5rem 1rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
