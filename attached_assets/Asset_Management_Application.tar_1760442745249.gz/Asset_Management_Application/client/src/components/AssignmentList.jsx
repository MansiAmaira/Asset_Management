import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAssets } from '../store/assetSlice';
import { fetchEmployees } from '../store/employeeSlice';
import { assignmentAPI } from '../services/api';

export default function AssignmentList() {
  const dispatch = useDispatch();
  const { list: assets } = useSelector((state) => state.assets);
  const { list: employees } = useSelector((state) => state.employees);
  const [assignments, setAssignments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ assetId: '', employeeId: '', notes: '' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    dispatch(fetchAssets());
    dispatch(fetchEmployees());
    loadAssignments();
  }, [dispatch]);

  const loadAssignments = async () => {
    try {
      const response = await assignmentAPI.getAll();
      setAssignments(response.data);
    } catch (error) {
      console.error('Failed to load assignments:', error);
    }
  };

  const handleAssign = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      await assignmentAPI.assignAsset(formData);
      setFormData({ assetId: '', employeeId: '', notes: '' });
      setShowModal(false);
      await loadAssignments();
      dispatch(fetchAssets());
    } catch (error) {
      alert('Failed to assign asset. Please check if the asset is available.');
    } finally {
      setLoading(false);
    }
  };

  const handleReturn = async (assignmentId) => {
    if (window.confirm('Are you sure you want to return this asset?')) {
      try {
        await assignmentAPI.returnAsset(assignmentId, { notes: 'Returned via UI' });
        await loadAssignments();
        dispatch(fetchAssets());
      } catch (error) {
        alert('Failed to return asset');
      }
    }
  };

  const availableAssets = assets.filter(a => a.status === 'AVAILABLE');
  const activeEmployees = employees.filter(e => e.status === 'ACTIVE');

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h2>Asset Assignments</h2>
        <button onClick={() => setShowModal(true)} style={{ padding: '0.75rem 1.5rem', backgroundColor: '#ffc107', color: '#212529', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: '500' }}>
          Assign Asset
        </button>
      </div>

      <div style={{ backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
          <thead style={{ backgroundColor: '#f8f9fa' }}>
            <tr>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Asset Name</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Serial Number</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Employee</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Assigned Date</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Returned Date</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Notes</th>
              <th style={{ padding: '0.75rem', textAlign: 'left', borderBottom: '2px solid #dee2e6' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {assignments.map((assignment) => (
              <tr key={assignment.id} style={{ borderBottom: '1px solid #dee2e6' }}>
                <td style={{ padding: '0.75rem' }}>{assignment.asset.assetName}</td>
                <td style={{ padding: '0.75rem' }}>{assignment.asset.serialNumber}</td>
                <td style={{ padding: '0.75rem' }}>{assignment.employee.fullName}</td>
                <td style={{ padding: '0.75rem' }}>{assignment.assignedDate}</td>
                <td style={{ padding: '0.75rem' }}>
                  {assignment.returnedDate ? (
                    assignment.returnedDate
                  ) : (
                    <span style={{ padding: '0.25rem 0.5rem', borderRadius: '12px', fontSize: '0.75rem', backgroundColor: '#fff3cd', color: '#856404' }}>
                      Active
                    </span>
                  )}
                </td>
                <td style={{ padding: '0.75rem' }}>{assignment.notes || '-'}</td>
                <td style={{ padding: '0.75rem' }}>
                  {!assignment.returnedDate && (
                    <button onClick={() => handleReturn(assignment.id)} style={{ padding: '0.25rem 0.75rem', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '0.75rem' }}>
                      Return
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 }}>
          <div style={{ backgroundColor: 'white', padding: '2rem', borderRadius: '8px', width: '100%', maxWidth: '500px' }}>
            <h3 style={{ marginBottom: '1.5rem' }}>Assign Asset to Employee</h3>
            <form onSubmit={handleAssign}>
              <div style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Select Asset</label>
                <select value={formData.assetId} onChange={(e) => setFormData({...formData, assetId: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}>
                  <option value="">Choose an asset...</option>
                  {availableAssets.map(asset => (
                    <option key={asset.id} value={asset.id}>
                      {asset.assetName} ({asset.serialNumber})
                    </option>
                  ))}
                </select>
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Select Employee</label>
                <select value={formData.employeeId} onChange={(e) => setFormData({...formData, employeeId: e.target.value})} required style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }}>
                  <option value="">Choose an employee...</option>
                  {activeEmployees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.fullName} - {emp.department}
                    </option>
                  ))}
                </select>
              </div>
              <div style={{ marginBottom: '1.5rem' }}>
                <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: '500' }}>Notes (Optional)</label>
                <textarea value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} rows="3" style={{ width: '100%', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '4px' }} />
              </div>
              <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end' }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ padding: '0.5rem 1rem', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                <button type="submit" disabled={loading} style={{ padding: '0.5rem 1rem', backgroundColor: '#ffc107', color: '#212529', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: '500' }}>
                  {loading ? 'Assigning...' : 'Assign'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
