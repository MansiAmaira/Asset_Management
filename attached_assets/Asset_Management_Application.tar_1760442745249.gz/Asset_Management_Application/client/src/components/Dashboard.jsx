import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAssetStatistics, fetchTypeStatistics } from '../store/assetSlice';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const dispatch = useDispatch();
  const { statistics, typeStatistics } = useSelector((state) => state.assets);

  useEffect(() => {
    dispatch(fetchAssetStatistics());
    dispatch(fetchTypeStatistics());
  }, [dispatch]);

  const statCards = [
    { label: 'Total Assets', value: statistics?.total || 0, color: '#007bff' },
    { label: 'Available', value: statistics?.available || 0, color: '#28a745' },
    { label: 'Assigned', value: statistics?.assigned || 0, color: '#ffc107' },
    { label: 'Under Repair', value: statistics?.underRepair || 0, color: '#dc3545' },
    { label: 'Retired', value: statistics?.retired || 0, color: '#6c757d' },
    { label: 'Spare Assets', value: statistics?.spare || 0, color: '#17a2b8' },
  ];

  return (
    <div>
      <h2 style={{ marginBottom: '1.5rem' }}>Asset Inventory Dashboard</h2>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        {statCards.map((stat) => (
          <div key={stat.label} style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', borderLeft: `4px solid ${stat.color}` }}>
            <div style={{ fontSize: '0.875rem', color: '#666', marginBottom: '0.5rem' }}>{stat.label}</div>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: stat.color }}>{stat.value}</div>
          </div>
        ))}
      </div>

      {typeStatistics && Object.keys(typeStatistics).length > 0 && (
        <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginBottom: '2rem' }}>
          <h3 style={{ marginBottom: '1rem' }}>Assets by Type</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '1rem' }}>
            {Object.entries(typeStatistics).map(([type, count]) => (
              <div key={type} style={{ padding: '1rem', backgroundColor: '#f8f9fa', borderRadius: '4px', textAlign: 'center' }}>
                <div style={{ fontWeight: 'bold', color: '#333' }}>{type}</div>
                <div style={{ fontSize: '1.5rem', color: '#007bff', marginTop: '0.5rem' }}>{count}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem' }}>
        <Link to="/assets" style={{ textDecoration: 'none' }}>
          <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', cursor: 'pointer', transition: 'transform 0.2s' }}>
            <h3 style={{ color: '#007bff', marginBottom: '0.5rem' }}>Asset Management</h3>
            <p style={{ color: '#666', fontSize: '0.875rem' }}>View and manage all assets</p>
          </div>
        </Link>
        <Link to="/employees" style={{ textDecoration: 'none' }}>
          <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', cursor: 'pointer', transition: 'transform 0.2s' }}>
            <h3 style={{ color: '#28a745', marginBottom: '0.5rem' }}>Employee Management</h3>
            <p style={{ color: '#666', fontSize: '0.875rem' }}>View and manage employees</p>
          </div>
        </Link>
        <Link to="/assignments" style={{ textDecoration: 'none' }}>
          <div style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', cursor: 'pointer', transition: 'transform 0.2s' }}>
            <h3 style={{ color: '#ffc107', marginBottom: '0.5rem' }}>Asset Assignments</h3>
            <p style={{ color: '#666', fontSize: '0.875rem' }}>Assign and track asset assignments</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
