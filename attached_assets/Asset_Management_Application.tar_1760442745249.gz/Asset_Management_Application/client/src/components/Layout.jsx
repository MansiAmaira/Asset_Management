import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../store/authSlice';

export default function Layout({ children }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);

  const handleLogout = async () => {
    await dispatch(logout());
    navigate('/login');
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f5f5f5' }}>
      <nav style={{ backgroundColor: '#343a40', color: 'white', padding: '1rem 2rem', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '1400px', margin: '0 auto' }}>
          <h1 style={{ fontSize: '1.5rem', margin: 0 }}>Asset Management</h1>
          <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
            <Link to="/dashboard" style={{ color: 'white', textDecoration: 'none' }}>Dashboard</Link>
            <Link to="/assets" style={{ color: 'white', textDecoration: 'none' }}>Assets</Link>
            <Link to="/employees" style={{ color: 'white', textDecoration: 'none' }}>Employees</Link>
            <Link to="/assignments" style={{ color: 'white', textDecoration: 'none' }}>Assignments</Link>
            <div style={{ borderLeft: '1px solid #6c757d', paddingLeft: '1rem', marginLeft: '0.5rem' }}>
              <span style={{ marginRight: '1rem' }}>Welcome, {user}</span>
              <button onClick={handleLogout} style={{ padding: '0.5rem 1rem', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>
      <main style={{ maxWidth: '1400px', margin: '0 auto', padding: '2rem' }}>
        {children}
      </main>
    </div>
  );
}
