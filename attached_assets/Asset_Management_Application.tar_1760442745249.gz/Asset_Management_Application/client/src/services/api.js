import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const authAPI = {
  login: (username, password) => {
    const formData = new URLSearchParams();
    formData.append('username', username);
    formData.append('password', password);
    return api.post('/auth/login', formData, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });
  },
  getCurrentUser: () => api.get('/auth/user'),
  logout: () => api.post('/auth/logout'),
};

export const employeeAPI = {
  getAll: () => api.get('/employees'),
  getById: (id) => api.get(`/employees/${id}`),
  create: (data) => api.post('/employees', data),
  update: (id, data) => api.put(`/employees/${id}`, data),
  delete: (id) => api.delete(`/employees/${id}`),
  getActive: () => api.get('/employees/active'),
};

export const assetAPI = {
  getAll: () => api.get('/assets'),
  getPaginated: (params) => api.get('/assets/paginated', { params }),
  getById: (id) => api.get(`/assets/${id}`),
  create: (data) => api.post('/assets', data),
  update: (id, data) => api.put(`/assets/${id}`, data),
  delete: (id) => api.delete(`/assets/${id}`),
  getByType: (type) => api.get(`/assets/type/${type}`),
  getByStatus: (status) => api.get(`/assets/status/${status}`),
  getStatistics: () => api.get('/assets/statistics'),
  getTypeStatistics: () => api.get('/assets/statistics/by-type'),
};

export const assignmentAPI = {
  assignAsset: (data) => api.post('/assignments/assign', data),
  returnAsset: (assignmentId, data) => api.put(`/assignments/return/${assignmentId}`, data),
  getAll: () => api.get('/assignments'),
  getAssetHistory: (assetId) => api.get(`/assignments/asset/${assetId}`),
  getEmployeeHistory: (employeeId) => api.get(`/assignments/employee/${employeeId}`),
  getActiveAssignment: (assetId) => api.get(`/assignments/asset/${assetId}/active`),
};

export default api;
