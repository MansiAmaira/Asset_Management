import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { assetAPI } from '../services/api';

export const fetchAssets = createAsyncThunk('assets/fetchAll', async () => {
  const response = await assetAPI.getAll();
  return response.data;
});

export const fetchAssetStatistics = createAsyncThunk('assets/fetchStatistics', async () => {
  const response = await assetAPI.getStatistics();
  return response.data;
});

export const fetchTypeStatistics = createAsyncThunk('assets/fetchTypeStatistics', async () => {
  const response = await assetAPI.getTypeStatistics();
  return response.data;
});

export const createAsset = createAsyncThunk('assets/create', async (data) => {
  const response = await assetAPI.create(data);
  return response.data;
});

export const updateAsset = createAsyncThunk('assets/update', async ({ id, data }) => {
  const response = await assetAPI.update(id, data);
  return response.data;
});

export const deleteAsset = createAsyncThunk('assets/delete', async (id) => {
  await assetAPI.delete(id);
  return id;
});

const assetSlice = createSlice({
  name: 'assets',
  initialState: {
    list: [],
    statistics: null,
    typeStatistics: null,
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchAssets.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchAssets.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload;
      })
      .addCase(fetchAssets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(fetchAssetStatistics.fulfilled, (state, action) => {
        state.statistics = action.payload;
      })
      .addCase(fetchTypeStatistics.fulfilled, (state, action) => {
        state.typeStatistics = action.payload;
      })
      .addCase(createAsset.fulfilled, (state, action) => {
        state.list.push(action.payload);
      })
      .addCase(updateAsset.fulfilled, (state, action) => {
        const index = state.list.findIndex(asset => asset.id === action.payload.id);
        if (index !== -1) {
          state.list[index] = action.payload;
        }
      })
      .addCase(deleteAsset.fulfilled, (state, action) => {
        state.list = state.list.filter(asset => asset.id !== action.payload);
      });
  },
});

export default assetSlice.reducer;
