# Asset Management Application

## Overview
A fullstack Asset Management Application built with Java Spring Boot backend and React + Redux frontend for managing employees, assets, and asset assignments.

## Technology Stack

### Backend
- Java Spring Boot 3.2.0
- Spring Data JPA (Entity Framework equivalent)
- Spring Security (Authentication)
- H2 In-Memory Database (Development)
- Maven (Build tool)
- Lombok (Reduce boilerplate)

### Frontend
- React 18+ with Vite
- Redux Toolkit (State Management)
- React Router (Navigation)
- Axios (HTTP Client)
- Inline styling

## Architecture

### Backend - Layered Architecture
- **Entity Layer**: JPA entities (Employee, Asset, AssignmentHistory)
- **Repository Layer**: Spring Data JPA repositories
- **Service Layer**: Business logic
- **Controller Layer**: REST API endpoints
- **Security Layer**: Spring Security configuration

### Frontend - Component-Based Architecture
- **Store**: Redux Toolkit slices (auth, employees, assets)
- **Services**: API client with Axios
- **Components**: React functional components
- **Routing**: React Router for SPA navigation

## Features

### Authentication
- Single-user login system
- Session-based authentication
- Default credentials: `admin` / `admin123`

### Employee Management
- Add, Edit, Delete, View employees
- Fields: ID, Full Name, Department, Email, Phone, Designation, Status

### Asset Management
- Complete CRUD operations for assets
- Fields: ID, Name, Type, Make/Model, Serial Number, Purchase Date, Warranty Expiry, Condition, Status, Spare Flag, Specifications
- Search and filter by type, status, serial number
- Sortable asset list

### Asset Assignment
- Assign available assets to employees
- Track assignment history
- Return assets functionality
- View assignment records

### Dashboard
- Asset statistics widgets
- Assets by type breakdown
- Quick navigation links

## Database Schema

### Employees Table
- id (PK, auto-generated)
- full_name
- department
- email (unique)
- phone_number
- designation
- status (ACTIVE/INACTIVE)

### Assets Table
- id (PK, auto-generated)
- asset_name
- asset_type
- make_model
- serial_number (unique)
- purchase_date
- warranty_expiry_date
- condition (NEW/GOOD/NEEDS_REPAIR/DAMAGED)
- status (AVAILABLE/ASSIGNED/UNDER_REPAIR/RETIRED)
- is_spare
- specifications

### Assignment History Table
- id (PK, auto-generated)
- asset_id (FK)
- employee_id (FK)
- assigned_date
- returned_date (nullable)
- notes

## Running the Application

### Backend
Port: 8080
Command: `mvn spring-boot:run`
Base URL: http://localhost:8080/api

### Frontend
Port: 5000
Command: `cd client && npm run dev`
URL: http://localhost:5000

### Workflows
Both workflows are configured and run automatically:
- Backend: Starts Spring Boot on port 8080
- Frontend: Starts Vite dev server on port 5000

## API Endpoints

### Authentication
- POST `/api/auth/login` - Login
- GET `/api/auth/user` - Get current user
- POST `/api/auth/logout` - Logout

### Employees
- GET `/api/employees` - Get all employees
- GET `/api/employees/{id}` - Get employee by ID
- POST `/api/employees` - Create employee
- PUT `/api/employees/{id}` - Update employee
- DELETE `/api/employees/{id}` - Delete employee

### Assets
- GET `/api/assets` - Get all assets
- GET `/api/assets/paginated` - Get paginated assets
- GET `/api/assets/{id}` - Get asset by ID
- POST `/api/assets` - Create asset
- PUT `/api/assets/{id}` - Update asset
- DELETE `/api/assets/{id}` - Delete asset
- GET `/api/assets/statistics` - Get asset statistics
- GET `/api/assets/statistics/by-type` - Get assets by type count

### Assignments
- POST `/api/assignments/assign` - Assign asset
- PUT `/api/assignments/return/{id}` - Return asset
- GET `/api/assignments` - Get all assignments
- GET `/api/assignments/asset/{id}` - Get asset history
- GET `/api/assignments/employee/{id}` - Get employee history

## Sample Data
The application includes sample data for demo purposes:
- 4 Employees (IT, HR, Finance departments)
- 6 Assets (Laptops, Monitors, Keyboards, etc.)
- Various statuses and conditions

## Security Notes
- CSRF protection disabled for API
- CORS configured for all origins (development only)
- Single admin user with BCrypt password hashing
- Session-based authentication with HTTP-only cookies

## Project Structure

```
.
├── src/main/java/com/sciforn/assetmanagement/
│   ├── AssetManagementApplication.java
│   ├── entity/
│   ├── repository/
│   ├── service/
│   ├── controller/
│   ├── config/
│   └── dto/
├── src/main/resources/
│   └── application.properties
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── store/
│   │   ├── services/
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
└── pom.xml
```

## Development Notes
- Backend uses H2 in-memory database (data resets on restart)
- Frontend proxies `/api` requests to backend on port 8080
- Vite dev server serves frontend on port 5000
- Hot reload enabled for both frontend and backend
