package com.sciforn.assetmanagement.dto;

import lombok.Data;

@Data
public class ReturnRequest {
    private String notes;
}
